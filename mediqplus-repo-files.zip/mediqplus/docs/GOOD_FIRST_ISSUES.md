# Starter issues to create on GitHub

Create these as issues and label them `good first issue` / `help wanted`. They show reviewers real activity and give contributors an entry point.

1. Add a synthetic demo-data seed script
2. Write tests for login and role-based access
3. Add empty, loading and error states to the patient list screen
4. Run an accessibility audit (axe / Lighthouse) and file findings
5. Add `.env.example` validation on startup with a helpful error message
6. Translate the UI labels for the front-desk screens into one Indian language
7. Add a screenshot gallery to the README
8. Improve setup docs after following them on a clean machine
