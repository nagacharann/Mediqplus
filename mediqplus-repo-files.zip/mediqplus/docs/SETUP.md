# Setup Guide

> Update the commands below to match the project's actual stack, then keep this file current. A setup guide that works from a clean machine is the most important contributor-facing doc.

## Prerequisites

- Git
- The runtime for this project (for example Node.js LTS or Python 3.11+)
- A database if required (see Architecture)

## Steps

```bash
git clone https://github.com/nagacharann/mediqplus.git
cd mediqplus

# 1. Install dependencies
# npm install          (Node)   or   pip install -r requirements.txt   (Python)

# 2. Configure environment
cp .env.example .env
# edit .env with your local values; never commit it

# 3. Start the app
# npm run dev          or   python manage.py runserver
```

## Demo data

Use synthetic data only. Never load real patient records into a development or demo environment.

## Running tests

```bash
# npm test      or      pytest
```

## Troubleshooting

Open an issue with your OS, runtime version, the command you ran, and the full error output.
