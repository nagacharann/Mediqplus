# Architecture

> Short overview for contributors. Update the stack and diagram to match the code.

## Overview

```
[ Browser UI ] --> [ Application / API layer ] --> [ Database ]
                         |
                         +--> Auth and roles (admin, doctor, front desk)
                         +--> Audit log
```

## Principles

1. **Least privilege:** every screen and endpoint checks the user's role.
2. **Auditability:** reads and writes of patient records are logged.
3. **Synthetic data in dev:** no real patient data outside a reviewed deployment.
4. **Clear states:** every view handles empty, loading, error and permission-denied cases.
5. **Replaceable AI:** any AI feature sits behind an interface, shows uncertainty, and requires human review.

## Key decisions

Record important choices as short notes in `docs/decisions/` (what, why, alternatives considered).
