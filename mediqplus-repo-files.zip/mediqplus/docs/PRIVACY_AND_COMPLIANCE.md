# Privacy and Compliance Notes

**This project is not certified or validated for clinical use.** The notes below are engineering guidance, not legal advice. Consult a qualified professional before handling real patient data.

## Status

- No claim of compliance with HIPAA, India's Digital Personal Data Protection Act 2023, or any medical-device regulation
- MediQPlus is not a diagnostic tool and does not provide medical advice

## Data handling principles

- Collect only the data the workflow needs
- Encrypt data in transit (HTTPS) and at rest in any real deployment
- Restrict access by role and log it
- Keep secrets out of the repository
- Provide a way to export and delete a patient's data on request

## Before a real clinic deployment

- [ ] Independent security review
- [ ] Data protection and consent review for the target jurisdiction
- [ ] Backup and recovery plan
- [ ] Incident response contact and process
- [ ] Clear written agreement with the clinic on responsibilities
