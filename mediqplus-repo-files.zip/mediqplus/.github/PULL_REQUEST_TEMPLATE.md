## What does this PR do?

<!-- One or two sentences -->

## Related issue

Closes #

## How was it tested?

<!-- Steps, screenshots (synthetic data only), or test names -->

## Checklist

- [ ] Focused on one change
- [ ] Tests added or updated
- [ ] Docs updated if behavior changed
- [ ] No real patient data, secrets or credentials included
- [ ] Security impact noted if auth, access control or storage changed
- [ ] UI changes checked for keyboard use and contrast
