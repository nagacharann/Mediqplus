---
name: Feature request
about: Suggest an improvement
labels: enhancement
---

**Who needs this, and what job are they trying to do?**

**What do they do today instead?**

**Proposed solution**

**Alternatives considered**
