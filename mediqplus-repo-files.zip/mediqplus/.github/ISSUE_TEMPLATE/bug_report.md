---
name: Bug report
about: Something is broken or behaves unexpectedly
labels: bug
---

**What happened?**

**What did you expect?**

**Steps to reproduce**
1.
2.
3.

**Environment** (OS, browser, runtime version, commit or release)

**Screenshots or logs** (use synthetic data only, no real patient information)
