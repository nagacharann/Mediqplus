# MediQPlus

Open-source healthcare management software for small and mid-sized clinics.

![status](https://img.shields.io/badge/status-early%20stage-orange) ![license](https://img.shields.io/badge/license-MIT-blue) ![PRs welcome](https://img.shields.io/badge/PRs-welcome-brightgreen)

## Why this exists

Most clinic and hospital management systems are priced and designed for large hospitals. Small clinics, especially in India, often fall back to paper registers and spreadsheets. MediQPlus is a free, self-hostable alternative that clinics and developers can run, audit and adapt, with a design-first approach: fewer clicks for front-desk staff, clear states for every screen, and safe handling of patient data.

## Who it is for

| Role | What they need |
|---|---|
| Front desk / receptionist | Fast patient registration, appointment booking, queue visibility |
| Doctor | Quick access to patient history, simple consultation notes |
| Clinic admin | Roles and permissions, audit trail, basic reports |
| Developers / students | A readable, well-documented reference implementation of a healthcare workflow app |

## Status

Early stage and under active development. Not yet validated for production clinical use. See [ROADMAP.md](ROADMAP.md) and [docs/PRIVACY_AND_COMPLIANCE.md](docs/PRIVACY_AND_COMPLIANCE.md) before handling real patient data.

## Modules

Edit this list to match what is built today. Keep it honest: ship what is checked, plan what is not.

- [ ] Patient registration and records
- [ ] Appointment scheduling and queue
- [ ] Doctor consultation notes
- [ ] Role-based access control (admin, doctor, front desk)
- [ ] Audit log of record access and changes
- [ ] Basic reports and exports

## Getting started

```bash
git clone https://github.com/nagacharann/mediqplus.git
cd mediqplus
# install dependencies and run the app: see docs/SETUP.md
```

Full instructions: [docs/SETUP.md](docs/SETUP.md).

## Documentation

- [Setup guide](docs/SETUP.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Privacy and compliance notes](docs/PRIVACY_AND_COMPLIANCE.md)
- [Roadmap](ROADMAP.md)
- [Changelog](CHANGELOG.md)

## Contributing

Contributions of all kinds are welcome: code, UX feedback, docs, translations, and clinic workflow input. Start with [CONTRIBUTING.md](CONTRIBUTING.md) and look for issues labelled `good first issue`.

## Security

Please do not open public issues for vulnerabilities. See [SECURITY.md](SECURITY.md).

## License

[MIT](LICENSE) © 2026 Naga Charan

## Maintainer

Naga Charan ([@nagacharann](https://github.com/nagacharann)): UI/UX designer and M.Tech (AI/ML) student working on product design, healthcare workflows and automation.
